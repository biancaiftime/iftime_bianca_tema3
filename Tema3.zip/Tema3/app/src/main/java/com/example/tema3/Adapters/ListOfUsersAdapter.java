package com.example.tema3.Adapters;

import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.tema3.Models.User;
import com.example.tema3.R;

import java.util.List;

public class ListOfUsersAdapter extends RecyclerView.Adapter<ListOfUsersAdapter.ViewHolder> {

    private List<User> mDataset;

    public ListOfUsersAdapter(List<User> users)
    {
        mDataset = users;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.my_text_view, viewGroup, false);

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.fullName.setText(mDataset.get(i).fullName);
        viewHolder.mark.setText(Float.toString(mDataset.get(i).mark));

    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView fullName;
        public TextView mark;

        public ViewHolder(View vCard)
        {
            super(vCard);
            fullName = vCard.findViewById(R.id.List_FullName);
            mark = vCard.findViewById(R.id.List_Mark);
        }
    }

    public void addItem(User user)
    {
        mDataset.add(user);
        notifyDataSetChanged();
    }

    public void deleteItem(User user)
    {
        for (User u : mDataset)
        {
            if(u.fullName.equals(user.fullName))
            {
                mDataset.remove(u);
                notifyDataSetChanged();
                break;
            }
        }
    }
}
