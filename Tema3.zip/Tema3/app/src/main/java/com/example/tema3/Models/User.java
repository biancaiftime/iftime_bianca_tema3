package com.example.tema3.Models;

public class User {
    public int Id;
    public String Name;
    public String Username;
    public String Emal;

    public User(int id, String name, String username, String emal) {
        Id = id;
        Name = name;
        Username = username;
        Emal = emal;
    }

    public User() {
    }
}
